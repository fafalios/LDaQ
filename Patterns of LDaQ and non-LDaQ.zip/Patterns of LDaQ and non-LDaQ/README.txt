==========================
Datasets:
- BIO2RDF (from USEWOD)
- BM (from LSQ)
- LGD (from LSQ and USEWOD)
- SWDF (from LSQ and USEWOD)
- DBPEDIA (from LSQ and USEWOD 2014-2015)
LSQ: https://aksw.github.io/LSQ/
USEWOD: http://usewod.org/
==========================
LDaQ = Linked Data-answerable Query
Non-LDaQ = Non-Linked Data-answerable Query
==========================
Each file contains two columns:
- Number of unique queries having the pattern
- Pattern (extracted using the method "getPattern" of the class "CheckAnswerability")
